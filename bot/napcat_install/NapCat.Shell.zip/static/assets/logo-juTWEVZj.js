const o="/webui/assets/logo-C2MGgWT2.png";export{o as l};
